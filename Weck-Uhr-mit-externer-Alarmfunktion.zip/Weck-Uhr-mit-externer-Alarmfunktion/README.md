# Weck-Uhr-mit-externer-Alarmfunktion
